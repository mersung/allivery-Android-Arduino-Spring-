package org.zerock.allivery;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AlliveryApplicationTests {

	@Test
	void contextLoads() {
	}

}
