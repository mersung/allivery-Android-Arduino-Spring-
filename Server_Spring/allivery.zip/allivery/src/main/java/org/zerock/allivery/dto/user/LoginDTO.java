package org.zerock.allivery.dto.user;

import lombok.Data;

@Data
public class LoginDTO {
    private String email;
    private String password;
}
