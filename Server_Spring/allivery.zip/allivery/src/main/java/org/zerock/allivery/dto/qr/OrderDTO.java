package org.zerock.allivery.dto.qr;

import lombok.Data;

@Data
public class OrderDTO {
    private String serialNum;
}
