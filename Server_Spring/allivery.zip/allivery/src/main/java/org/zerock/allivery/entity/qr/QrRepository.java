package org.zerock.allivery.entity.qr;

import org.springframework.data.jpa.repository.JpaRepository;

public interface QrRepository extends JpaRepository<Qr, Long> {
}
