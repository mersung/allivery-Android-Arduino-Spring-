package org.zerock.allivery.entity.role;

public enum UserRole {
    USER, ADMIn
}
